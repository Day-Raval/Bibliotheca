public class Main {
     
    public static class ex{
        public static int days=0;
            }
 
    public static void main(String[] args) {
         
        // App.create();
        App.login();
    }
}